import pickle

def get_training_pairs_range(bin_file_path, start, end):
    with open(bin_file_path, 'rb') as bf:
        pairs = pickle.load(bf)
    total_pairs = len(pairs)
    if start < 0 or start >= total_pairs:
        return f"Start index {start} is out of range. Available pairs: 0 to {total_pairs - 1}."
    if end > total_pairs:
        print(
            f"Note: Requested range {start}-{end} exceeds available training pairs. Presenting range {start}-{total_pairs} instead.")
        end = total_pairs
    return pairs[start:end]


def access_prompts(bin_file, start, end):
    selected_pairs = get_training_pairs_range(bin_file, start, end)
    if isinstance(selected_pairs, list):
        print(f"\nRetrieved {len(selected_pairs)} training pairs:")
        for idx, (prompt, data) in enumerate(selected_pairs, start=start):
            print(f"Pair {idx}:")
            print(f"  Prompt: {prompt}")
            print(f"  Data:   {data}\n")
    else:
        print(selected_pairs)
