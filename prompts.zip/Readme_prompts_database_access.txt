Important Note:
This is the selected prompt training data upgraded upto 2025/0303. Note that the design of our system is to fed every human-validated prompts, including those are used in
our paper, to continuously improve the model performances time by time. To provide feedback to help us improve the model, or interested to see a rolled-back knowledge
capability, please contact developers.

Access method:
Use access_prompts (bin_file, start_index, end_index) of prompts_database_access.py in python programming environments (e.g., PyCharm). The .bin file is the prompt database, start_index and end_index represent the range of database access.
