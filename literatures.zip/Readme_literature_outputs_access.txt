Important Note:
This dataset contains 500 selected example literature summaries for knowledge training. The full-text articles and associated images supplied during fine-tuning are not included due to file-size limitations. Interested readers can consult the original publications listed in the summaries.

Access method:
Use access_prompts(bin_file, start_index, end_index) in access_literature_outputs.py within a Python environment (e.g., PyCharm). The .bin file contains the summaries. Indices start at 0; start_index is included and end_index is excluded.